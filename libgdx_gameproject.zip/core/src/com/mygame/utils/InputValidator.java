package com.mygame.utils;

public class InputValidator {
    public static boolean isValidUsername(String input) {
        return input.matches("^[A-Za-z]{3,12}$");
    }
}