package com.mygame.storage;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;

public class PreferencesManager {
    private Preferences prefs = Gdx.app.getPreferences("UserPrefs");

    public void saveUsername(String name) {
        prefs.putString("username", name);
        prefs.flush();
    }

    public String getUsername() {
        return prefs.getString("username", "Player");
    }
}