package com.mygame.screens;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.mygame.MainGame;
import com.mygame.screens.GameScreen;

public class LoadingScreen implements Screen {
    private final MainGame game;
    private BitmapFont font;

    public LoadingScreen(MainGame game) {
        this.game = game;
        this.font = new BitmapFont();
    }

    @Override
    public void show() {
        game.assets.loadAll();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.assets.update();

        game.batch.begin();
        font.draw(game.batch, "Loading...", Gdx.graphics.getWidth()/2f - 30, Gdx.graphics.getHeight()/2f);
        game.batch.end();

        if (game.assets.isFinished()) {
            game.setScreen(new GameScreen(game));
        }
    }

    @Override public void resize(int w, int h) {}
    @Override public void dispose() {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}