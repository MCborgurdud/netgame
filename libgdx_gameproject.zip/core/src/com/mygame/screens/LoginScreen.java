package com.mygame.screens;

import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygame.MainGame;
import com.mygame.utils.InputValidator;
import com.mygame.screens.LoadingScreen;

public class LoginScreen implements Screen {
    private final MainGame game;
    private Stage stage;
    private TextField usernameField;
    private TextButton playButton;

    public LoginScreen(MainGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
        Table table = new Table();
        table.setFillParent(true);
        stage.addActor(table);

        Label titleLabel = new Label("My Game", skin);
        usernameField = new TextField("", skin);
        usernameField.setMessageText("Enter Username");

        playButton = new TextButton("Play", skin);
        playButton.setDisabled(true);

        table.add(titleLabel).padBottom(20).row();
        table.add(usernameField).width(200).padBottom(10).row();
        table.add(playButton).width(100);

        usernameField.setTextFieldListener((textField, c) -> {
            boolean valid = InputValidator.isValidUsername(usernameField.getText());
            playButton.setDisabled(!valid);
        });

        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                String name = usernameField.getText();
                game.preferences.saveUsername(name);
                game.setScreen(new LoadingScreen(game));
            }
        });
    }

    @Override public void render(float delta) { Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); stage.act(); stage.draw(); }
    @Override public void resize(int w, int h) { stage.getViewport().update(w, h, true); }
    @Override public void hide() { stage.dispose(); }
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void dispose() {}
}