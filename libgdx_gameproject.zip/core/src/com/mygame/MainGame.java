package com.mygame;

import com.badlogic.gdx.Game;
import com.mygame.utils.AssetManagerWrapper;
import com.mygame.storage.PreferencesManager;
import com.mygame.screens.LoginScreen;

public class MainGame extends Game {
    public AssetManagerWrapper assets;
    public PreferencesManager preferences;

    @Override
    public void create() {
        assets = new AssetManagerWrapper();
        preferences = new PreferencesManager();
        setScreen(new LoginScreen(this));
    }
}